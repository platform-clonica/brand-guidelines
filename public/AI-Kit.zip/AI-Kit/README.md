# interactīus · AI Kit

Paquete de marca para herramientas de IA. Generado el 2026-06-05 desde brand.interactius.com.
Brand package for AI tools. Generated 2026-06-05 from brand.interactius.com.

## Contenido / Contents

- `llms.txt` — el manual completo en formato para LLMs: identidad, tono, vocabulario prohibido, ejemplos aprobados/rechazados, prompts. / The full manual in LLM format.
- `brand.json` — tokens y reglas en JSON programático. / Tokens and rules as JSON.
- `logo/` — logotipo e isotipo en SVG (positivo y negativo). / Logotype and isotype SVGs.
- `sistema-grafico/` — las tres formas del sistema gráfico en SVG. / The three graphic-system shapes.

## Cómo usarlo / How to use

- **NotebookLM**: añade `llms.txt` y `brand.json` como fuentes del notebook.
- **Claude (Projects)**: sube el contenido del kit al Project knowledge.
- **ChatGPT / Gemini**: adjunta `llms.txt` al inicio de la conversación, o pega la URL https://brand.interactius.com/llms.txt
- **Validación**: el copy generado puede comprobarse contra https://brand.interactius.com/api/eval (POST).

La versión viva siempre está en https://brand.interactius.com — si este kit tiene más de unas semanas, descarga uno nuevo.
The living version is always at https://brand.interactius.com — if this kit is more than a few weeks old, download a fresh one.
